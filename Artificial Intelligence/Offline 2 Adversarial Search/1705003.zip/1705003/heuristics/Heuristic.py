class Heuristic:

    def get_value(self, state):
        raise NotImplementedError("Heuuristic abstract method")
