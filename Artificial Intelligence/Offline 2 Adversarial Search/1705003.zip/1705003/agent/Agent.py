class Agent:

    def get_move(self, state, first_player):
        """

        :params: State
        :return: move of first player [1,6]
        """
        raise NotImplementedError()
