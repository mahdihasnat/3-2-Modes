//
// Created by mahdi on 11/28/2021.
//

#ifndef OFFLINE_1_A_STAR_SEARCH_HAMMING_H
#define OFFLINE_1_A_STAR_SEARCH_HAMMING_H

#include "../board/Board2D.h"

int Hamming(const Board2D &board2D);

#endif //OFFLINE_1_A_STAR_SEARCH_HAMMING_H
