//
// Created by mahdi on 11/30/2021.
//

#ifndef OFFLINE_1_A_STAR_SEARCH_LINEARCONFLICT_H
#define OFFLINE_1_A_STAR_SEARCH_LINEARCONFLICT_H

#include "../board/Board2D.h"

int LinearConflict(const Board2D & board2D);

#endif //OFFLINE_1_A_STAR_SEARCH_LINEARCONFLICT_H
