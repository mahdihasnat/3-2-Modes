//
// Created by mahdi on 11/29/2021.
//

#ifndef OFFLINE_1_A_STAR_SEARCH_MANHATTAN_H
#define OFFLINE_1_A_STAR_SEARCH_MANHATTAN_H
#include "../board/Board2D.h"

int Manhattan(const Board2D &board2D );

#endif //OFFLINE_1_A_STAR_SEARCH_MANHATTAN_H
