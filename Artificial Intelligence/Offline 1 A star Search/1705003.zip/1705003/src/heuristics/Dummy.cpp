//
// Created by mahdi on 11/28/2021.
//

#include "Dummy.h"


int Dummy(const Board2D &board2D) {
    return 0;
}
