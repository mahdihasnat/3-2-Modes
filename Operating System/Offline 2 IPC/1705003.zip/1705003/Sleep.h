//
// Created by mahdi on 12/22/2021.
//

#ifndef OFFLINE_2_IPC_SLEEP_H
#define OFFLINE_2_IPC_SLEEP_H

void sleep_milliseconds(int);

#endif //OFFLINE_2_IPC_SLEEP_H
