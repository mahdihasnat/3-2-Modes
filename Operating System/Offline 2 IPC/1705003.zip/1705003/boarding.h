//
// Created by mahdi on 12/22/2021.
//

#ifndef OFFLINE_2_IPC_BOARDING_H
#define OFFLINE_2_IPC_BOARDING_H

#include "passenger.h"

bool boarding_check_boarding_pass(Passenger const &);

#endif //OFFLINE_2_IPC_BOARDING_H
