//
// Created by mahdi on 12/22/2021.
//

#ifndef OFFLINE_2_IPC_VIP_CHANNEL_H
#define OFFLINE_2_IPC_VIP_CHANNEL_H

#include "passenger.h"

void vip_channel_to_gate(Passenger const &);

void vip_channel_to_special_kiosk(Passenger const &);

#endif //OFFLINE_2_IPC_VIP_CHANNEL_H
