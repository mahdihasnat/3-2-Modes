//
// Created by mahdi on 12/23/2021.
//

#ifndef OFFLINE_2_IPC_TIMER_H
#define OFFLINE_2_IPC_TIMER_H

#include<string>

using namespace std;

void timer_init();

void timer_destroy();

string timer_get_time_str();

#endif //OFFLINE_2_IPC_TIMER_H
