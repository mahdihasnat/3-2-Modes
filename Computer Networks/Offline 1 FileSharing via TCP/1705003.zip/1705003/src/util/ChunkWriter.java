package util;

import java.io.FileOutputStream;

public class ChunkWriter {
    FileOutputStream fos;

}
